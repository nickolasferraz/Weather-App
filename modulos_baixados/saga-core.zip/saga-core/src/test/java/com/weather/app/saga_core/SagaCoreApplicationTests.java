package com.weather.app.saga_core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SagaCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
