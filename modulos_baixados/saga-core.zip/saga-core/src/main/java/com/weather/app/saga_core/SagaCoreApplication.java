package com.weather.app.saga_core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SagaCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SagaCoreApplication.class, args);
	}

}
